<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Book</title>
</head>
<body>
    <form method="POST" action="<?php echo e(route('update-book', $book->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <h1>Edit Book Form</h1>
        
        <div>Book Title</div>
        <input type="text" name="title" value="<?php echo e($book->title); ?>" required>
        
        <div>Writer Name</div>
        <input type="text" name="writer" value="<?php echo e($book->writer); ?>" required>
        
        <div>Year</div>
        <input type="number" name="published_year" value="<?php echo e($book->published_year); ?>" required>
        
        <div>Book Cover</div>
        <input type="file" name="cover_path">
        
        <br><br>
        <button type="submit">Update</button>
        <a href="/">Cancel</a>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\webdevsecondproject\resources\views/books-edit.blade.php ENDPATH**/ ?>