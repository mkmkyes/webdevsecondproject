<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <form method="GET" action="/create-book">
        <input type="submit" value="+ Add New Book">
    </form>
    <br>

    <table border="1" cellpadding="8" cellspacing="0">
        <thead>
            <tr>
                <th>Cover</th>
                <th>Title</th>
                <th>Writer</th>
                <th>Published Year</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><img src="<?php echo e(asset('storage/' . $book->cover_path)); ?>" width="50" alt="Cover"></td>
                    <td><?php echo e($book->title); ?></td>
                    <td><?php echo e($book->writer); ?></td>
                    <td><?php echo e($book->published_year); ?></td>
                    <td>
                        <form method="GET" action="<?php echo e(route('edit-book', $book->id)); ?>" style="display:inline;">
                            <input type="submit" value="Edit">
                        </form>

                        <form method="POST" action="<?php echo e(route('destroy-book', $book->id)); ?>" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="submit" value="Delete">
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\webdevsecondproject\resources\views/welcome.blade.php ENDPATH**/ ?>